****** HOW TO USE ******

1/ CLICK Hello World
2/ Sign In: 2 account had in database
	1. duy / 123
	2. long / 123
3/ If don't have CLICK Create
4/ Sign Up: fill information and CLICK 


****** ProGuard ******

1/ choose Build -> Select Build Variants -> choose Active Build Variant is release

2/ Now project will change to Proguard
