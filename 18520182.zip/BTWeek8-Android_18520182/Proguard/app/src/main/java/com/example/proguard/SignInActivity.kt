package com.example.proguard

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.proguard.databinding.ActivitySignInBinding

class SignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val activitySignInBinding: ActivitySignInBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_sign_in)

        activitySignInBinding.tvCreateAccount.setOnClickListener {
            var intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }


        activitySignInBinding.btnSignIn.setOnClickListener {
            var username = activitySignInBinding.edtUserName.text.toString()
            var password = activitySignInBinding.edtPassword.text.toString()
            if ( MainActivity.dbAdapter.checkUser(username , password) ) {
                Toast.makeText(this@SignInActivity, "Dang nhap thanh cong ", Toast.LENGTH_SHORT).show()
                Log.d("aaaaa" , "success")
                startActivity( Intent(this@SignInActivity , HomeActivity::class.java) )
            }
            else {
                Toast.makeText(this@SignInActivity, "Dang nhap that bai !!! ", Toast.LENGTH_SHORT).show()

                Log.d("aaaaa" , "failed")
            }
        }
    }
}