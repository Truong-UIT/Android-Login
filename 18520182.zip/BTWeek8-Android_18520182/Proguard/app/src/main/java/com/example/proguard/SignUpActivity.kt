package com.example.proguard

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.databinding.DataBindingUtil
import com.example.proguard.databinding.ActivitySignUpBinding

class SignUpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        var activitySignUpBinding : ActivitySignUpBinding = DataBindingUtil.setContentView(this,R.layout.activity_sign_up)

        activitySignUpBinding.btnSignUp.setOnClickListener {
            var name = activitySignUpBinding.edtName.text.toString()
            var username = activitySignUpBinding.edtUserName.text.toString()
            var password = activitySignUpBinding.edtPassword.text.toString()

            MainActivity.dbAdapter.createUser(name , username , password)
            MainActivity.users = MainActivity.getData()
            Log.d("aaaaaaa" , MainActivity.users.toString())
        }
    }
}