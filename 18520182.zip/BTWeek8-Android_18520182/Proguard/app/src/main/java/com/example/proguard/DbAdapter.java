package com.example.proguard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.jetbrains.annotations.Nullable;

public class DbAdapter {
    public final String KEY_ID = "_id";
    public final String KEY_NAME = "name";
    public final String KEY_USERNAME = "username";
    public final String KEY_PASSWORD = "password";

    private DatabaseHelper dbHelper;
    private SQLiteDatabase sqLiteDatabase;
    private static final String DATABASE_NAME = "Database_Demo";
    private static final String DATABASE_TABLE = "users";
    private static final int DATABASE_VERSION = 2;
    private final Context context;


    public DbAdapter(Context ctx) {
        this.context = ctx;
    }

    public com.example.proguard.DbAdapter open() {
        dbHelper = new DatabaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
        sqLiteDatabase = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public long createUser(String name , String username , String password) {
        ContentValues inititalValues = new ContentValues();

        inititalValues.put(KEY_NAME, name);
        inititalValues.put(KEY_USERNAME, username);
        inititalValues.put(KEY_PASSWORD, password);
        return sqLiteDatabase.insert(DATABASE_TABLE, null, inititalValues);
    } public boolean checkUser (String username , String password)
   {
        String query = String.format("SELECT * from %s where username = \"%s\" and password = \"%s\""
                ,DATABASE_TABLE,username , password );
        Cursor c = sqLiteDatabase.rawQuery(query , null);

        Log.d("aaaaa" , c.toString());

        if ( c.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }
    public boolean deleteUser(long rowId) {
        return sqLiteDatabase.delete(DATABASE_TABLE, KEY_ID + "=" + rowId, null) > 0;
    }

    public boolean deleteAllUsers() {
        return sqLiteDatabase.delete(DATABASE_TABLE, null, null) > 0;

    }


    public Cursor getAllUsers() {
        return sqLiteDatabase.query(DATABASE_TABLE, new String[]{KEY_ID, KEY_NAME , KEY_USERNAME ,KEY_PASSWORD}, null, null, null, null, null);
    }
}

