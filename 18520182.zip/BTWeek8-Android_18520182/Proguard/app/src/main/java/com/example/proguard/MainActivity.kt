package com.example.proguard

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.proguard.MainActivity.Companion.cursor
import com.example.proguard.MainActivity.Companion.dbAdapter
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    companion object {
        lateinit  var dbAdapter : DbAdapter
        lateinit var cursor: Cursor
        var users: ArrayList<String> = ArrayList()
        fun getData(): ArrayList<String> {
            cursor = dbAdapter.allUsers
            while (cursor?.moveToNext()!!) {

                users.add(
                    cursor!!.getString(cursor!!.getColumnIndex(dbAdapter.KEY_NAME))
                            + cursor!!.getString(cursor!!.getColumnIndex(dbAdapter.KEY_USERNAME))
                            + cursor!!.getString(cursor!!.getColumnIndex(dbAdapter.KEY_PASSWORD))

                )
            }
            return users
        }
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ///////
        dbAdapter = DbAdapter(this)

        dbAdapter.open()
        dbAdapter.deleteAllUsers()
//        for (i in 0..9) {
//            dbAdapter.createUser("Nguyễn Văn An $i" , "An $i" , "Annn $i")
//        }
//
//        users = getData()
//        Log.d("aaaaaaaaaaa", users.toString())
        dbAdapter.createUser("duy","duy","123")
        dbAdapter.createUser("long","long","123")
        var tvHello = findViewById<TextView>(R.id.tvHello).setOnClickListener {
            startActivity(Intent (this , SignInActivity::class.java))
        }
    }

}